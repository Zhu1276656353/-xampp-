$(function(){
    var lis = document.querySelectorAll('.chat-header-nav li');
    for(var i=0;i<lis.length;i++){
        lis[i].onclick = function(){
            for(var j = 0;j<lis.length;j++){
                lis[j].className = '';
            }
            this.className = 'active';
        }
    }
})
function waterFlow() {
    // 获取所有card
    var card = $('.hearSay-content-card');
    // 获取一行可以摆放几个card
    var rowsNum = parseInt($(".hearSay-content").width() / $('.hearSay-content-card').width());
    // 存储每一列的高度
    var colsHeightArr = [];
    for (var i = 0; i < card.length; i++) {
        // 判断：获取第一行的元素
        if (i < rowsNum) {
            // 第一行的高，直接放入colsHeightArr中
            colsHeightArr.push($(card[i]).height());
        } else {
            // 判断：获取第二行以后的元素
            //获取第一行最小的高度
            var minHeight = Math.min.apply(null, colsHeightArr);
            //获取最小高度的索引
            var minHeightOfIndex = colsHeightArr.indexOf(minHeight);
            //给第二行开始的元素设置绝对定位
            card[i].style.position = 'absolute';
            // 第二行开始的元素的top = 第一行最小高度的top + 自己设置的间距
            card[i].style.top = minHeight + 80 + 'px';
            // 第二行开始的元素的left = 第一行最小高度的left
            card[i].style.left = card.eq(minHeightOfIndex).position().left + 'px';
            // 更新最小高度 = 第一行最小高度 + 第二行第一个元素的高度
            colsHeightArr[minHeightOfIndex] = colsHeightArr[minHeightOfIndex] + card[i].offsetHeight + 40;
            // 更新瀑布流的高度
            $(".hearSay-content").height(Math.max.apply(null, colsHeightArr));
        }
    }
}
//瀑布流
$(function () {
    waterFlow();
})

window.onscroll = debounce(reachBottom, 300);
//防抖：在一定的延时时间内，如果多次触发，就清除掉前面的触发，只触发最后一次
function debounce(fn, delay) {
    var timer = null;
    return function () {
        if (timer) {
            clearTimeout(timer);
        }
        timer = setTimeout(fn, delay);
    }
}


//触底判断: 瀑布流最后一个元素的高 + 底部间距 < 浏览器高度 + 滚动条高度
function reachBottom() {
    // 获取滚动条距离和浏览器高度
    var scrollTop = $(window).scrollTop();
    var windowHeight = $(window).height();
    // 获取最后一个元素的高度
    var card = $('.hearSay-content-card');
    var lastCardHeight = card.eq(card.length - 1).offset().top + 240;
    if (scrollTop + windowHeight > lastCardHeight) {
        // 加载数据
        $.ajax({
            type: "get",
            url: "http://localhost/blueberrypai_server/data/聊聊/chat.json",
            success: function (chat) {
                for (var i = 0; i < chat.data.length; i++) {
                    $(".hearSay-content").append('<div class="hearSay-content-card">\
                        <div class="hearSayear-content-card-header">\
                            <div class="hearSayear-content-card-header-img">\
                                <img src="'+ chat.data[i].picture + '" alt="">\
                            </div>\
                            <div class="hearSayear-content-card-header-title">\
                                <p>'+ chat.data[i].title + '</p>\
                                <p>'+ chat.data[i].name + '</p>\
                            </div>\
                            <div class="hearSayear-content-card-header-label">\
                                <span>'+ chat.data[i].label + '</span>\
                            </div>\
                        </div>\
                        <div class="hearSayear-content-card-body">\
                            <p>'+ chat.data[i].text + '</p>\
                        </div>\
                        <div class="hearSayear-content-card-footer">\
                            <p>'+ chat.data[i].desc + '</p>\
                            <span><span class="iconfont">&#xec8c;</span>'+ chat.data[i].like + '</span>\
                            <span><span class="iconfont">&#xf0106;</span>'+ chat.data[i].comment + '</span>\
                        </div>\
                    </div>')
                }
            }
        })
    }
    waterFlow();
}
