$(function () {
    function musicPlay() {
        // 注意获得的是audio标签，而不是audio标签的jquery对象
        var audio = $("#audio")[0];
        if (audio.paused) {
            audio.play();
            $("#playBtn img")[0].src = "./img/乐章/播放.png";
        } else {
            audio.pause();
            $("#playBtn img")[0].src = "./img/乐章/暂停.webp";
        }

        var playTimer = null;
        playTimer = setInterval(function () {
            // 判断播放是否暂停：暂停清除定时器，减少内存消耗
            if (audio.paused) {
                clearInterval(playTimer);
            }
            // 获取当前播放时间
            var currentTime = audio.currentTime;
            var minuteCurrentTime = parseInt(currentTime / 60);
            var secondCurrentTime = parseInt(currentTime % 60);
            // 获取总时长
            var duration = audio.duration;
            var minuteDuration = parseInt(duration / 60);
            var secondDuration = parseInt(duration % 60);
            // 格式化时间
            function format(minute, second) {
                if (minute < 10) {
                    minute = "0" + minute;
                }
                if (second < 10) {
                    second = "0" + second;
                }
                return minute + ":" + second;
            }
            var currentTimeProgress = format(minuteCurrentTime, secondCurrentTime);
            var durationProgress = format(minuteDuration, secondDuration);
            // 显示时间
            $("#passTime").text(currentTimeProgress);
            $("#totalTime").text(durationProgress);

            // 设置进度条
            var progressWidth = $(".progress-bar").width();
            var progress = currentTime / duration * progressWidth;
            $(".progress-bar-progress").width(progress);
            // 判断播放是否结束
            if (currentTime === duration) {
                clearInterval(playTimer);
                $("#playBtn img")[0].src = "./img/乐章/暂停.webp";
            }
        }, 1000)
    }
    $("#playBtn").click(function () {
        musicPlay();
    })
})
// 获取歌曲信息的网络请求
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/乐章/song.json",
    success: function (song) {
        $(".song-content-title span").append("<b>" + song.song[0].number + "</b>&nbsp;播放");
        $(".song-content-title").prepend("<span>" + song.song[0].title + "</span>");
        $(".song-content-body-left").append("<img src='" + song.song[0].img + "' >");
        $(".song-content-body-right").append("<p>" + song.song[0].content + "</p>");
        $(".song-content-bottom").prepend("<audio src='" + song.song[0].audio + "' id='audio'></audio>")
    }
})

//文章内容
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/乐章/movementContent.json",
    success: function (movementContent) {
        $(".article-content-title").prepend("<h3>" + movementContent.artical.artical_title + "</h3>")
        $(".eye-num").text(movementContent.artical.eye_num);
        $(".wechat-num").text(movementContent.artical.wei_chat_num);
        $(".create-time span").text(movementContent.artical.artical_create_time);
        // 文章内容，要用decodeURI转义html标签
        $(".article-content-body").html(decodeURI(movementContent.artical.artical_cont));
        //？？？？？？？？？？为什么执行不了
        // for (var i = 0; i < movementContent.artical.labels.length; i++) {
        //     $(".article-content-label").append("<span class='label'>" + movementContent.artical.labels[i] + "</span>");
        // }
    }
})


//相关阅读
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/乐章/relatedReading.json",
    success: function (relatedReading) {
        for (var i = 0; i < relatedReading.relatedReading.length; i++) {
            $(".related-reading-content").append('<div class="related-reading-content-box">\
                            <div class="related-reading-content-box-img">\
                                <img src="'+ relatedReading.relatedReading[i].img + '" alt="">\
                            </div>\
                            <div class="related-reading-content-box-text">\
                                <span>'+ relatedReading.relatedReading[i].title + '</span>\
                            </div>\
                        </div>')
        }
        // 点赞喜欢
        for (var j = 0; j < relatedReading.like.length; j++) {
            $(".like-person").append('<li>\
                                <div class="like-person-img">\
                                   <img src="'+ relatedReading.like[j].img + '">\
                                 </div>\
                                 <p class="like-person-name">'+ relatedReading.like[j].like_person + '</p>\
                         </li>')
        }
    }
})

// 评论
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/乐章/remarks.json",
    success: function (remarks) {
        for (var i = 0; i < remarks.remarks.length; i++) {
            $(".remarks").append('<div class="remarks-content">\
                            <div class="remarks-content-img">\
                                <img src="'+ remarks.remarks[i].remarks_img + '" alt="">\
                            </div>\
                            <div class="remarks-content-text">\
                                <div class="remarks-content-text-top">\
                                    <div class="remarks-content-text-top-left">\
                                        <span class="remarks-content-text-top-left-name">'+ remarks.remarks[i].remarks_person + '</span>\
                                        <span class="remarks-content-text-top-left-time">'+ remarks.remarks[i].remarks_time + '</span>\
                                    </div>\
                                    <div class="remarks-content-text-top-right">\
                                        <span><span class="iconfont">&#xec8c;</span>'+ remarks.remarks[i].remarks_like + '</span>\
                                        <span><span class="iconfont">&#xf0106;</span>'+ remarks.remarks[i].remarks_say + '</span>\
                                    </div>\
                                </div>\
                                <div class="remarks-content-text-bottom">\
                                    <span>'+ remarks.remarks[i].remarks_content + '</span>\
                                </div>\
                            </div>\
                        </div>')
        }
    }
})

// 其他作品
$.ajax({ 
    type: "get",
    url: "http://localhost/blueberrypai_server/data/乐章/other.json",
    success: function (other) {
        for (var i = 0; i < other.other.length; i++) {
            $(".article-right-box .article-right-box-content:eq(0)").append("<li>" + other.other[i].compose + "</li>")
        }
        for (var j = 0; j < other.recommend.length; j++) {
            $(".article-right-box .article-right-box-content:eq(1)").append("<li>" + other.recommend[j].text + "</li>")
        }
    }
})
