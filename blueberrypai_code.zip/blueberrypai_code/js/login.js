
function forgotman() {
    alert('请联系管理员以重置密码。');
}

// 登录界面和注册界面切换
$(function () {
    $("#login").click(function () {
        $("#loginForm").css("transform", "rotateY(180deg)");
        $("#registerForm").css("transform", "rotateY(0deg)");
    })
    $("#register").click(function () {
        $("#loginForm").css("transform", "rotateY(0deg)");
        $("#registerForm").css("transform", "rotateY(180deg)");
    })
})

// 登录按钮点击事件
$("#loginBtn").click(function () {
    // .....阻止表单默认提交行为Start.....
    var pass = $("#passwordLogin")[0];
    var name = $("#usernameLogin")[0];
    // 检查元素是否存在
    if (!pass || !name) {
        console.error('无法找到密码或用户名输入框，请检查 HTML 元素是否存在。');
        return;
    }
    var passValue = pass.value.toLowerCase();
    var nameValue = name.value.toLowerCase();

    // 判断用户名和密码是否为空
    if (nameValue === "" || passValue === "") {
        alert("请输入用户名和密码");

        return; // 阻止后续逻辑执行
    }
    // .....阻止表单默认提交行为End.....


    $.ajax({
        type: "post",
        url: "http://localhost/blueberrypai_server/login.php",
        data: {
            username: $("#usernameLogin").val(),
            password: $("#passwordLogin").val()
        },
        success: function (data) {
            // 将用户名存储到 localStorage 中
            localStorage.setItem("username", JSON.parse(data).data[0].username);
            if (data) {
                // 登录成功后跳转到主页
                window.location.href = "index.html";
            }
        },
        error: function (error) {
            console.error(error);
        }
    })
})

// 注册按钮点击事件
$("#registerBtn").click(function () {
    // .....阻止表单默认提交行为Start.....
    var pass = $("#passwordRegister")[0];
    var name = $("#usernameRegister")[0];
    // 检查元素是否存在
    if (!pass || !name) {
        console.error('无法找到密码或用户名输入框，请检查 HTML 元素是否存在。');
        return;
    }
    var passValue = pass.value.toLowerCase();
    var nameValue = name.value.toLowerCase();

    // 判断用户名和密码是否为空
    if (nameValue === "" || passValue === "") {
        alert("请输入用户名和密码");
        return; // 阻止后续逻辑执行
    }
    // .....阻止表单默认提交行为End.....

    
    $.ajax({
        type: "post",
        url: "http://localhost/blueberrypai_server/register.php",
        data: {
            username: $("#usernameRegister").val(),
            password: $("#passwordRegister").val()
        },
        success: function (data) {
            console.log(data);
        },
        error: function (error) {
            console.error(error);
        }
    })
})

