// $.ajax({
//     type:"get",
//     url:"http://localhost/blueberrypai_server/data/诚品/goods.json",
//     success:function(goods){
//         for(var i = 0;i < goods.data.length;i++){
//             $(".goods-content").append('<div class="goods-content-box">\
//                 <!-- 商品图片 -->\
//                 <div class="goods-content-box-left">\
//                     <img src="'+goods.data[i].img+'" alt="">\
//                 </div>\
//                 <!-- 商品信息 -->\
//                 <div class="goods-content-box-right">\
//                     <p class="goods-content-box-right-title">'+goods.data[i].title+'</p>\
//                     <p class="goods-content-box-right-introduce">'+goods.data[i].introduce+'</p>\
//                     <button>商品详情</button>\
//                 </div>\
//             </div>')
//         }
//     }
// })


// 分页
$("#pager").zPager({
    totalData: 55
});

function currentPage(currentPage) {
    /*
        触发页码数位置： Page/js/jquery.z-pager.js 64行
    */
    // console.log("当前页码数：" + currentPage);
    $(".goods-content").html('');
    $.ajax({
        type: "get",
        url:"http://localhost/blueberrypai_server/data/诚品/goods.json",
        data: {
            page: currentPage
        },
        success: function (data) {
            for (var i = 0; i < data.data.length; i++) {
                $(".goods-content").append('<div class="goods-content-box">\
                                                 <div class="goods-content-box-left">\
                                                     <img src="'+ data.data[i].img + '" alt="">\
                                                 </div>\
                                                <div class="goods-content-box-right">\
                                                    <p class="goods-content-box-right-title">'+ data.data[i].title + '</p>\
                                                    <p class="goods-content-box-right-introduce">'+ data.data[i].introduce + '</p>\
                                                    <button>商品详情</button>\
                                                </div>\
                                            </div>')
            }
        }
    })
}