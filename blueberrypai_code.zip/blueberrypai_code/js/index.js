$(function () {
    var mySwiper = new Swiper('.swiper', {
        loop: true, // 循环模式选项

        // 如果需要分页器
        pagination: {
            el: '.swiper-pagination',
        },

        // 如果需要前进后退按钮
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    })
    $(function () {
        var index = 0;
        var timer = null;
        $(".swiper-button-next").click(function () {
            slideMove();
        })
        function slideMove() {
            index++;
            if (index > $(".swiper-slide").length - 1) {
                index = 0;
            }
            $(".swiper-slide").eq(index).addClass('active').siblings().removeClass('active');
        }
        timer = setInterval(function () {
            $(".swiper-button-next").click();
        }, 3000)
    })
})

//banner部分的网络请求
$.ajax({
    type: 'get',
    url: 'http://localhost/blueberrypai_server/data/首页/banner.json',
    success: function (banner) {
        $(".slide1 h3").html(banner.banner[0].title);
        $(".slide2 h3").html(banner.banner[1].title);
        $(".slide3 h3").html(banner.banner[2].title);
        $(".slide4 h3").html(banner.banner[3].title);
        $(".slide1 p").html(banner.banner[0].content);
        $(".slide2 p").html(banner.banner[1].content);
        $(".slide3 p").html(banner.banner[2].content);
        $(".slide4 p").html(banner.banner[3].content);
    },
    error: function (err) {
        console.log(err);
    }
})
//乐章部分的网络请求
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/首页/movement.json",
    success: function (movement) {
        // console.log(movement);
        for (var i = 0; i < movement.movement.length; i++) {
            $(".movement-content").append('\
                 <div class="movement-content-box">\
                    <div class="movement-content-box-img">\
                        <img src="'+ movement.movement[i].img + '" alt="">\
                    </div>\
                    <div class="movement-content-box-text font">\
                        <p>'+ movement.movement[i].compose + '</p>\
                        <p>'+ movement.movement[i].singer + '</p>\
                        <p>'+ movement.movement[i].song + '</p>\
                    </div>\
                </div>\
                ')
        }
    },
    error: function (err) {
        console.log(err);
    }
})
//游记部分的网络请求
$.ajax({
    type: "get",
    url: "http://localhost/blueberrypai_server/data/首页/travel.json",
    success: function (travel) {
        // console.log(travel);
        for (var i = 0; i < travel.travel.length; i++) {
            $(".travel-content").append('\
                 <div class="travel-content-box">\
                    <div class="travel-content-box-img">\
                        <img src="'+ travel.travel[i].img + '" alt="">\
                    </div>\
                    <div class="travel-content-box-text">\
                        <span class="font">'+ travel.travel[i].title + '</span>\
                    </div>\
                    <div class="travel-content-box-rightContent">\
                        <span>'+ travel.travel[i].content + '</span>\
                    </div>\
                </div>\
            ')
        } 
    }
})
//获取用户名并显示在页面上
var username = localStorage.getItem("username");
if (username) {
    // console.log(username);
    $(".header-login-register").html('<a href="#" class="login">' + username + '</a><a href="#" id="logout" style="font-size:12px;" class="register">退出</a>');
}
$("#logout").click(function () {
    // 清除localStorage中的用户名
    localStorage.removeItem("username");
    window.location.href = "index.html";
})