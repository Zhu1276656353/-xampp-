<?php
    $page = $_GET["page"];
    if($page == 1){
        $json_data = file_get_contents("./data/诚品/goods.json");
        echo $json_data;
    }else{
        echo "请求失败";
    }
?>