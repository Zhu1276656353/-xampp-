<?php
   //听说
   $json_hearSay = file_get_contents("./data/听说/hearSay.json");
   echo $json_hearSay;

   //聊聊
   $json_chat = file_get_contents("./data/聊聊/chat.json");
   echo $json_chat;

   //诚品
   $json_goods = file_get_contents("./data/诚品/goods.json");
   echo $json_goods;
?>