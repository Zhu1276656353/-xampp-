<?php
    $username = $_POST["username"];
    $password = $_POST["password"];
    $musicFan = new mysqli("localhost", "root", "", "musicfan");
    if($musicFan -> connect_errno){
        die("链接数据库失败:".$musicFan -> connect_errno);
    }else{
        $musicFan -> set_charset("utf8");
        $blueberrypai = "select * from blueberrypai where username = '$username' and password = '$password'"; 
        $result = $musicFan -> query($blueberrypai);
        $data = $result -> fetch_all(MYSQLI_ASSOC);
        $musicFan -> close();
        if($result -> num_rows){
            echo json_encode(array("status" => "success", "message" => "登录成功！","data" => $data));
        }else{
            echo json_encode(array("status" => "error", "message" => "用户名或密码错误！"));
        }
    }
?>